--[[
    CPE40032
    Pong Remake

    pong-12
    "The Resize Update"

    -- Main Program --



    Originally programmed by Atari in 1972. Features two
    paddles, controlled by players, with the goal of getting
    the ball past your opponent's edge. First to 10 points wins.

    This version is built to more closely resemble the NES than
    the original Pong machines or the Atari 2600 in terms of
    resolution, though in widescreen (16:9) so it looks nicer on
    modern systems.
]]

-- push is a library that will allow us to draw our game at a virtual
-- resolution, instead of however large our window is; used to provide
-- a more retro aesthetic
--
-- https://github.com/Ulydev/push
push = require 'push'

-- the "Class" library we're using will allow us to represent anything in
-- our game as code, rather than keeping track of many disparate variables and
-- methods
--
-- https://github.com/vrld/hump/blob/master/class.lua
Class = require 'class'

-- our Paddle class, which stores position and dimensions for each Paddle
-- and the logic for rendering them
require 'Paddle'

-- our Ball class, which isn't much different than a Paddle structure-wise
-- but which will mechanically function very differently
require 'Ball'

WINDOW_WIDTH = 1280
WINDOW_HEIGHT = 720

VIRTUAL_WIDTH = 432
VIRTUAL_HEIGHT = 243

-- speed at which we will move our paddle; multiplied by dt in update
PADDLE_SPEED = 200
PADDLE_SPEED2 = 100
--DIFF
PADDLE_SPEEDez = 65
PADDLE_SPEEDmedium = 100
PADDLE_SPEEDhard = 200

--[[
    Runs when the game first starts up, only once; used to initialize the game.
]]
function love.load()
    -- set love's default filter to "nearest-neighbor", which essentially
    -- means there will be no filtering of pixels (blurriness), which is
    -- important for a nice crisp, 2D look
    love.graphics.setDefaultFilter('nearest', 'nearest')

    -- set the title of our application window
    love.window.setTitle('Pong')

    -- "seed" the RNG so that calls to random are always random
    -- use the current time, since that will vary on startup every time
    math.randomseed(os.time())

    -- initialize our nice-looking retro text fonts
    smallFont = love.graphics.newFont('font.ttf', 8)
    largeFont = love.graphics.newFont('font.ttf', 16)
    scoreFont = love.graphics.newFont('font.ttf', 32)
    love.graphics.setFont(smallFont)

    -- set up our sound effects; later, we can just index this table and
    -- call each entry's `play` method
    sounds = {
        ['paddle_hit'] = love.audio.newSource('sounds/paddle_hit.wav', 'static'),
        ['score'] = love.audio.newSource('sounds/score.wav', 'static'),
        ['wall_hit'] = love.audio.newSource('sounds/wall_hit.wav', 'static')
    }

    -- initialize window with virtual resolution
    push:setupScreen(VIRTUAL_WIDTH, VIRTUAL_HEIGHT, WINDOW_WIDTH, WINDOW_HEIGHT, {
        fullscreen = false,
        resizable = true,
        vsync = true
    })

    -- initialize score variables, used for rendering on the screen and keeping
    -- track of the winner
    player1Score = 0
    player2Score = 0

    -- either going to be 1 or 2; whomever is scored on gets to serveSingleLeft the
    -- following turn
    servingPlayer = 1

    -- initialize player paddles and ball
    player1 = Paddle(10, 30, 5, 20)
    player2 = Paddle(VIRTUAL_WIDTH - 10, VIRTUAL_HEIGHT - 30, 5, 20)
    ball = Ball(VIRTUAL_WIDTH / 2 - 2, VIRTUAL_HEIGHT / 2 - 2, 4, 4)

    gameState = 'start'
end

--[[
    Called by LÖVE whenever we resize the screen; here, we just want to pass in the
    width and height to push so our virtual resolution can be resized as needed.
]]
function love.resize(w, h)
    push:resize(w, h)
end

--[[
    Runs every frame, with "dt" passed in, our delta in seconds
    since the last frame, which LÖVE2D supplies us.
]]
function love.update(dt)

	-- SINGLE PLAYER LEFT EZ DIFF
    if gameState == 'serveSingleLeft' then
        -- before switching to play, initialize ball's velocity based
        -- on player who last scored
        ball.dy = math.random(-50, 50)
        if servingPlayer == 1 then
            ball.dx = math.random(140, 200)
        else
            ball.dx = -math.random(140, 200)
        end
    elseif gameState == 'playSingleLeft' then
        -- detect ball collision with paddles, reversing dx if true and
        -- slightly increasing it, then altering the dy based on the position of collision
        if ball:collides(player1) then
            ball.dx = -ball.dx * 1.03
            ball.x = player1.x + 5

            -- keep velocity going in the same direction, but randomize it
            if ball.dy < 0 then
                ball.dy = -math.random(10, 150)
            else
                ball.dy = math.random(10, 150)
            end

            sounds['paddle_hit']:play()
        end
        if ball:collides(player2) then
            ball.dx = -ball.dx * 1.03
            ball.x = player2.x - 4

            -- keep velocity going in the same direction, but randomize it
            if ball.dy < 0 then
                ball.dy = -math.random(10, 150)
            else
                ball.dy = math.random(10, 150)
            end

            sounds['paddle_hit']:play()
        end

        -- detect upper and lower screen boundary collision and reverse if collided
        if ball.y <= 0 then
            ball.y = 0
            ball.dy = -ball.dy
            sounds['wall_hit']:play()
        end

        -- -4 to account for the ball's size
        if ball.y >= VIRTUAL_HEIGHT - 4 then
            ball.y = VIRTUAL_HEIGHT - 4
            ball.dy = -ball.dy
            sounds['wall_hit']:play()
        end

        -- if we reach the left or right edge of the screen,
        -- go back to start and update the score
        if ball.x < 0 then
            servingPlayer = 1
            player2Score = player2Score + 1
            sounds['score']:play()

            -- if we've reached a score of 10, the game is over; set the
            -- state to done so we can show the victory message
            if player2Score == 10 then
                winningPlayer = 2
                gameState = 'doneSingleLeft'
            else
                gameState = 'serveSingleLeft'
                -- places the ball in the middle of the screen, no velocity
                ball:reset()
            end
        end

        if ball.x > VIRTUAL_WIDTH then
            servingPlayer = 2
            player1Score = player1Score + 1
            sounds['score']:play()

            if player1Score == 10 then
                winningPlayer = 1
                gameState = 'doneSingleLeft'
            else
                gameState = 'serveSingleLeft'
                ball:reset()
            end
        end
    end
    if gameState == 'serveSingleLeft' or gameState == 'playSingleLeft' then
		    -- player 1 movement
		    if love.keyboard.isDown('w') then
		        player1.dy = -PADDLE_SPEED
		    elseif love.keyboard.isDown('s') then
		        player1.dy = PADDLE_SPEED
		    else
		        player1.dy = 0
		    end

		    -- player 2 movement
			if (player2.y - ball.y) > 0 then
				player2.dy = -PADDLE_SPEEDez
				elseif (player2.y - ball.y) < 0 then
				player2.dy = PADDLE_SPEEDez
				else
				player2.dy = 0
			end
		    -- update our ball based on its DX and DY only if we're in play state;
		    -- scale the velocity by dt so movement is framerate-independent
		    if gameState == 'playSingleLeft' then
		        ball:update(dt)
		    end
    end





-- SINGLE PLAYER LEFT MID DIFF

    if gameState == 'serveSingleLeftMid' then
        -- before switching to play, initialize ball's velocity based
        -- on player who last scored
        ball.dy = math.random(-50, 50)
        if servingPlayer == 1 then
            ball.dx = math.random(140, 200)
        else
            ball.dx = -math.random(140, 200)
        end
    elseif gameState == 'playSingleLeftMid' then
        -- detect ball collision with paddles, reversing dx if true and
        -- slightly increasing it, then altering the dy based on the position of collision
        if ball:collides(player1) then
            ball.dx = -ball.dx * 1.03
            ball.x = player1.x + 5

            -- keep velocity going in the same direction, but randomize it
            if ball.dy < 0 then
                ball.dy = -math.random(10, 150)
            else
                ball.dy = math.random(10, 150)
            end

            sounds['paddle_hit']:play()
        end
        if ball:collides(player2) then
            ball.dx = -ball.dx * 1.03
            ball.x = player2.x - 4

            -- keep velocity going in the same direction, but randomize it
            if ball.dy < 0 then
                ball.dy = -math.random(10, 150)
            else
                ball.dy = math.random(10, 150)
            end

            sounds['paddle_hit']:play()
        end

        -- detect upper and lower screen boundary collision and reverse if collided
        if ball.y <= 0 then
            ball.y = 0
            ball.dy = -ball.dy
            sounds['wall_hit']:play()
        end

        -- -4 to account for the ball's size
        if ball.y >= VIRTUAL_HEIGHT - 4 then
            ball.y = VIRTUAL_HEIGHT - 4
            ball.dy = -ball.dy
            sounds['wall_hit']:play()
        end

        -- if we reach the left or right edge of the screen,
        -- go back to start and update the score
        if ball.x < 0 then
            servingPlayer = 1
            player2Score = player2Score + 1
            sounds['score']:play()

            -- if we've reached a score of 10, the game is over; set the
            -- state to done so we can show the victory message
            if player2Score == 10 then
                winningPlayer = 2
                gameState = 'doneSingleLeftMid'
            else
                gameState = 'serveSingleLeftMid'
                -- places the ball in the middle of the screen, no velocity
                ball:reset()
            end
        end

        if ball.x > VIRTUAL_WIDTH then
            servingPlayer = 2
            player1Score = player1Score + 1
            sounds['score']:play()

            if player1Score == 10 then
                winningPlayer = 1
                gameState = 'doneSingleLeftMid'
            else
                gameState = 'serveSingleLeftMid'
                ball:reset()
            end
        end
    end
    if gameState == 'serveSingleLeftMid' or gameState == 'playSingleLeftMid' then
		    -- player 1 movement
		    if love.keyboard.isDown('w') then
		        player1.dy = -PADDLE_SPEED
		    elseif love.keyboard.isDown('s') then
		        player1.dy = PADDLE_SPEED
		    else
		        player1.dy = 0
		    end

		    -- player 2 movement
			if (player2.y - ball.y) > 0 then
				player2.dy = -PADDLE_SPEEDmedium
				elseif (player2.y - ball.y) < 0 then
				player2.dy = PADDLE_SPEEDmedium
				else
				player2.dy = 0
			end
		    -- update our ball based on its DX and DY only if we're in play state;
		    -- scale the velocity by dt so movement is framerate-independent
		    if gameState == 'playSingleLeftMid' then
		        ball:update(dt)
		    end
    end





	-- SINGLE PLAYER LEFT HARD DIFF
    if gameState == 'serveSingleLeftHard' then
        -- before switching to play, initialize ball's velocity based
        -- on player who last scored
        ball.dy = math.random(-50, 50)
        if servingPlayer == 1 then
            ball.dx = math.random(140, 200)
        else
            ball.dx = -math.random(140, 200)
        end
    elseif gameState == 'playSingleLeftHard' then
        -- detect ball collision with paddles, reversing dx if true and
        -- slightly increasing it, then altering the dy based on the position of collision
        if ball:collides(player1) then
            ball.dx = -ball.dx * 1.03
            ball.x = player1.x + 5

            -- keep velocity going in the same direction, but randomize it
            if ball.dy < 0 then
                ball.dy = -math.random(10, 150)
            else
                ball.dy = math.random(10, 150)
            end

            sounds['paddle_hit']:play()
        end
        if ball:collides(player2) then
            ball.dx = -ball.dx * 1.03
            ball.x = player2.x - 4

            -- keep velocity going in the same direction, but randomize it
            if ball.dy < 0 then
                ball.dy = -math.random(10, 150)
            else
                ball.dy = math.random(10, 150)
            end

            sounds['paddle_hit']:play()
        end

        -- detect upper and lower screen boundary collision and reverse if collided
        if ball.y <= 0 then
            ball.y = 0
            ball.dy = -ball.dy
            sounds['wall_hit']:play()
        end

        -- -4 to account for the ball's size
        if ball.y >= VIRTUAL_HEIGHT - 4 then
            ball.y = VIRTUAL_HEIGHT - 4
            ball.dy = -ball.dy
            sounds['wall_hit']:play()
        end

        -- if we reach the left or right edge of the screen,
        -- go back to start and update the score
        if ball.x < 0 then
            servingPlayer = 1
            player2Score = player2Score + 1
            sounds['score']:play()

            -- if we've reached a score of 10, the game is over; set the
            -- state to done so we can show the victory message
            if player2Score == 10 then
                winningPlayer = 2
                gameState = 'doneSingleLeftHard'
            else
                gameState = 'serveSingleLeftHard'
                -- places the ball in the middle of the screen, no velocity
                ball:reset()
            end
        end

        if ball.x > VIRTUAL_WIDTH then
            servingPlayer = 2
            player1Score = player1Score + 1
            sounds['score']:play()

            if player1Score == 10 then
                winningPlayer = 1
                gameState = 'doneSingleLeftHard'
            else
                gameState = 'serveSingleLeftHard'
                ball:reset()
            end
        end
    end
    if gameState == 'serveSingleLeftHard' or gameState == 'playSingleLeftHard' then
		    -- player 1 movement
		    if love.keyboard.isDown('w') then
		        player1.dy = -PADDLE_SPEED
		    elseif love.keyboard.isDown('s') then
		        player1.dy = PADDLE_SPEED
		    else
		        player1.dy = 0
		    end

		    -- player 2 movement
			if (player2.y - ball.y) > 0 then
				player2.dy = -PADDLE_SPEEDhard
				elseif (player2.y - ball.y) < 0 then
				player2.dy = PADDLE_SPEEDhard
				else
				player2.dy = 0
			end
		    -- update our ball based on its DX and DY only if we're in play state;
		    -- scale the velocity by dt so movement is framerate-independent
		    if gameState == 'playSingleLeftHard' then
		        ball:update(dt)
		    end
    end









-- SINGLE PLAYER RIGHT EZ

if gameState == 'serveSingleRight' then
        -- before switching to play, initialize ball's velocity based
        -- on player who last scored
        ball.dy = math.random(-50, 50)
        if servingPlayer == 1 then
            ball.dx = math.random(140, 200)
        else
            ball.dx = -math.random(140, 200)
        end
    elseif gameState == 'playSingleRight' then
        -- detect ball collision with paddles, reversing dx if true and
        -- slightly increasing it, then altering the dy based on the position of collision
        if ball:collides(player1) then
            ball.dx = -ball.dx * 1.03
            ball.x = player1.x + 5

            -- keep velocity going in the same direction, but randomize it
            if ball.dy < 0 then
                ball.dy = -math.random(10, 150)
            else
                ball.dy = math.random(10, 150)
            end

            sounds['paddle_hit']:play()
        end
        if ball:collides(player2) then
            ball.dx = -ball.dx * 1.03
            ball.x = player2.x - 4

            -- keep velocity going in the same direction, but randomize it
            if ball.dy < 0 then
                ball.dy = -math.random(10, 150)
            else
                ball.dy = math.random(10, 150)
            end

            sounds['paddle_hit']:play()
        end

        -- detect upper and lower screen boundary collision and reverse if collided
        if ball.y <= 0 then
            ball.y = 0
            ball.dy = -ball.dy
            sounds['wall_hit']:play()
        end

        -- -4 to account for the ball's size
        if ball.y >= VIRTUAL_HEIGHT - 4 then
            ball.y = VIRTUAL_HEIGHT - 4
            ball.dy = -ball.dy
            sounds['wall_hit']:play()
        end

        -- if we reach the left or right edge of the screen,
        -- go back to start and update the score
        if ball.x < 0 then
            servingPlayer = 1
            player2Score = player2Score + 1
            sounds['score']:play()

            -- if we've reached a score of 10, the game is over; set the
            -- state to done so we can show the victory message
            if player2Score == 10 then
                winningPlayer = 2
                gameState = 'doneSingleRight'
            else
                gameState = 'serveSingleRight'
                -- places the ball in the middle of the screen, no velocity
                ball:reset()
            end
        end

        if ball.x > VIRTUAL_WIDTH then
            servingPlayer = 2
            player1Score = player1Score + 1
            sounds['score']:play()

            if player1Score == 10 then
                winningPlayer = 1
                gameState = 'doneSingleRight'
            else
                gameState = 'serveSingleRight'
                ball:reset()
            end
        end
    end
    if gameState == 'serveSingleRight' or gameState =='playSingleRight'then
		    -- player 2 movement
			if (player1.y - ball.y) > 0 then
				player1.dy = -PADDLE_SPEEDez
				elseif (player1.y - ball.y) < 0 then
				player1.dy = PADDLE_SPEEDez
				else
				player1.dy = 0
			end


		    -- player 2 movement
		    if love.keyboard.isDown('up') then
		        player2.dy = -PADDLE_SPEED
		    elseif love.keyboard.isDown('down') then
		        player2.dy = PADDLE_SPEED
		    else
		        player2.dy = 0
		    end

		    -- update our ball based on its DX and DY only if we're in play state;
		    -- scale the velocity by dt so movement is framerate-independent
		    if gameState == 'playSingleRight' then
		        ball:update(dt)
		    end
    end


--SINGLE PLAYER RIGHT MID

if gameState == 'serveSingleRightMid' then
        -- before switching to play, initialize ball's velocity based
        -- on player who last scored
        ball.dy = math.random(-50, 50)
        if servingPlayer == 1 then
            ball.dx = math.random(140, 200)
        else
            ball.dx = -math.random(140, 200)
        end
    elseif gameState == 'playSingleRightMid' then
        -- detect ball collision with paddles, reversing dx if true and
        -- slightly increasing it, then altering the dy based on the position of collision
        if ball:collides(player1) then
            ball.dx = -ball.dx * 1.03
            ball.x = player1.x + 5

            -- keep velocity going in the same direction, but randomize it
            if ball.dy < 0 then
                ball.dy = -math.random(10, 150)
            else
                ball.dy = math.random(10, 150)
            end

            sounds['paddle_hit']:play()
        end
        if ball:collides(player2) then
            ball.dx = -ball.dx * 1.03
            ball.x = player2.x - 4

            -- keep velocity going in the same direction, but randomize it
            if ball.dy < 0 then
                ball.dy = -math.random(10, 150)
            else
                ball.dy = math.random(10, 150)
            end

            sounds['paddle_hit']:play()
        end

        -- detect upper and lower screen boundary collision and reverse if collided
        if ball.y <= 0 then
            ball.y = 0
            ball.dy = -ball.dy
            sounds['wall_hit']:play()
        end

        -- -4 to account for the ball's size
        if ball.y >= VIRTUAL_HEIGHT - 4 then
            ball.y = VIRTUAL_HEIGHT - 4
            ball.dy = -ball.dy
            sounds['wall_hit']:play()
        end

        -- if we reach the left or right edge of the screen,
        -- go back to start and update the score
        if ball.x < 0 then
            servingPlayer = 1
            player2Score = player2Score + 1
            sounds['score']:play()

            -- if we've reached a score of 10, the game is over; set the
            -- state to done so we can show the victory message
            if player2Score == 10 then
                winningPlayer = 2
                gameState = 'doneSingleRightMid'
            else
                gameState = 'serveSingleRightMid'
                -- places the ball in the middle of the screen, no velocity
                ball:reset()
            end
        end

        if ball.x > VIRTUAL_WIDTH then
            servingPlayer = 2
            player1Score = player1Score + 1
            sounds['score']:play()

            if player1Score == 10 then
                winningPlayer = 1
                gameState = 'doneSingleRightMid'
            else
                gameState = 'serveSingleRightMid'
                ball:reset()
            end
        end
    end
    if gameState == 'serveSingleRightMid' or gameState =='playSingleRightMid'then
		    -- player 2 movement
			if (player1.y - ball.y) > 0 then
				player1.dy = -PADDLE_SPEEDmedium
				elseif (player1.y - ball.y) < 0 then
				player1.dy = PADDLE_SPEEDmedium
				else
				player1.dy = 0
			end


		    -- player 2 movement
		    if love.keyboard.isDown('up') then
		        player2.dy = -PADDLE_SPEED
		    elseif love.keyboard.isDown('down') then
		        player2.dy = PADDLE_SPEED
		    else
		        player2.dy = 0
		    end

		    -- update our ball based on its DX and DY only if we're in play state;
		    -- scale the velocity by dt so movement is framerate-independent
		    if gameState == 'playSingleRightMid' then
		        ball:update(dt)
		    end
    end




--SINGLE PLAYER RIGHT HARD

if gameState == 'serveSingleRightHard' then
        -- before switching to play, initialize ball's velocity based
        -- on player who last scored
        ball.dy = math.random(-50, 50)
        if servingPlayer == 1 then
            ball.dx = math.random(140, 200)
        else
            ball.dx = -math.random(140, 200)
        end
    elseif gameState == 'playSingleRightHard' then
        -- detect ball collision with paddles, reversing dx if true and
        -- slightly increasing it, then altering the dy based on the position of collision
        if ball:collides(player1) then
            ball.dx = -ball.dx * 1.03
            ball.x = player1.x + 5

            -- keep velocity going in the same direction, but randomize it
            if ball.dy < 0 then
                ball.dy = -math.random(10, 150)
            else
                ball.dy = math.random(10, 150)
            end

            sounds['paddle_hit']:play()
        end
        if ball:collides(player2) then
            ball.dx = -ball.dx * 1.03
            ball.x = player2.x - 4

            -- keep velocity going in the same direction, but randomize it
            if ball.dy < 0 then
                ball.dy = -math.random(10, 150)
            else
                ball.dy = math.random(10, 150)
            end

            sounds['paddle_hit']:play()
        end

        -- detect upper and lower screen boundary collision and reverse if collided
        if ball.y <= 0 then
            ball.y = 0
            ball.dy = -ball.dy
            sounds['wall_hit']:play()
        end

        -- -4 to account for the ball's size
        if ball.y >= VIRTUAL_HEIGHT - 4 then
            ball.y = VIRTUAL_HEIGHT - 4
            ball.dy = -ball.dy
            sounds['wall_hit']:play()
        end

        -- if we reach the left or right edge of the screen,
        -- go back to start and update the score
        if ball.x < 0 then
            servingPlayer = 1
            player2Score = player2Score + 1
            sounds['score']:play()

            -- if we've reached a score of 10, the game is over; set the
            -- state to done so we can show the victory message
            if player2Score == 10 then
                winningPlayer = 2
                gameState = 'doneSingleRightHard'
            else
                gameState = 'serveSingleRightHard'
                -- places the ball in the middle of the screen, no velocity
                ball:reset()
            end
        end

        if ball.x > VIRTUAL_WIDTH then
            servingPlayer = 2
            player1Score = player1Score + 1
            sounds['score']:play()

            if player1Score == 10 then
                winningPlayer = 1
                gameState = 'doneSingleRightHard'
            else
                gameState = 'serveSingleRightHard'
                ball:reset()
            end
        end
    end
    if gameState == 'serveSingleRightHard' or gameState =='playSingleRightHard'then
		    -- player 2 movement
			if (player1.y - ball.y) > 0 then
				player1.dy = -PADDLE_SPEEDmedium
				elseif (player1.y - ball.y) < 0 then
				player1.dy = PADDLE_SPEEDmedium
				else
				player1.dy = 0
			end


		    -- player 2 movement
		    if love.keyboard.isDown('up') then
		        player2.dy = -PADDLE_SPEED
		    elseif love.keyboard.isDown('down') then
		        player2.dy = PADDLE_SPEED
		    else
		        player2.dy = 0
		    end

		    -- update our ball based on its DX and DY only if we're in play state;
		    -- scale the velocity by dt so movement is framerate-independent
		    if gameState == 'playSingleRightHard' then
		        ball:update(dt)
		    end
    end












--MULTIPLAYER
if gameState == 'serveMulti' then
        -- before switching to play, initialize ball's velocity based
        -- on player who last scored
        ball.dy = math.random(-50, 50)
        if servingPlayer == 1 then
            ball.dx = math.random(140, 200)
        else
            ball.dx = -math.random(140, 200)
        end
    elseif gameState == 'playMulti' then
        -- detect ball collision with paddles, reversing dx if true and
        -- slightly increasing it, then altering the dy based on the position of collision
        if ball:collides(player1) then
            ball.dx = -ball.dx * 1.03
            ball.x = player1.x + 5

            -- keep velocity going in the same direction, but randomize it
            if ball.dy < 0 then
                ball.dy = -math.random(10, 150)
            else
                ball.dy = math.random(10, 150)
            end

            sounds['paddle_hit']:play()
        end
        if ball:collides(player2) then
            ball.dx = -ball.dx * 1.03
            ball.x = player2.x - 4

            -- keep velocity going in the same direction, but randomize it
            if ball.dy < 0 then
                ball.dy = -math.random(10, 150)
            else
                ball.dy = math.random(10, 150)
            end

            sounds['paddle_hit']:play()
        end

        -- detect upper and lower screen boundary collision and reverse if collided
        if ball.y <= 0 then
            ball.y = 0
            ball.dy = -ball.dy
            sounds['wall_hit']:play()
        end

        -- -4 to account for the ball's size
        if ball.y >= VIRTUAL_HEIGHT - 4 then
            ball.y = VIRTUAL_HEIGHT - 4
            ball.dy = -ball.dy
            sounds['wall_hit']:play()
        end

        -- if we reach the left or right edge of the screen,
        -- go back to start and update the score
        if ball.x < 0 then
            servingPlayer = 1
            player2Score = player2Score + 1
            sounds['score']:play()

            -- if we've reached a score of 10, the game is over; set the
            -- state to done so we can show the victory message
            if player2Score == 10 then
                winningPlayer = 2
                gameState = 'doneMulti'
            else
                gameState = 'serveMulti'
                -- places the ball in the middle of the screen, no velocity
                ball:reset()
            end
        end

        if ball.x > VIRTUAL_WIDTH then
            servingPlayer = 2
            player1Score = player1Score + 1
            sounds['score']:play()

            if player1Score == 10 then
                winningPlayer = 1
                gameState = 'doneMulti'
            else
                gameState = 'serveMulti'
                ball:reset()
            end
        end
    end
    if gameState == 'serveMulti' or gameState =='playMulti'then
		     -- player 1 movement
			    if love.keyboard.isDown('w') then
			        player1.dy = -PADDLE_SPEED
			    elseif love.keyboard.isDown('s') then
			        player1.dy = PADDLE_SPEED
			    else
			        player1.dy = 0
			    end

			    -- player 2 movement
			    if love.keyboard.isDown('up') then
			        player2.dy = -PADDLE_SPEED
			    elseif love.keyboard.isDown('down') then
			        player2.dy = PADDLE_SPEED
			    else
			        player2.dy = 0
			    end
		    -- update our ball based on its DX and DY only if we're in play state;
		    -- scale the velocity by dt so movement is framerate-independent
		    if gameState == 'playMulti' then
		        ball:update(dt)
		    end
    end





    player1:update(dt)
    player2:update(dt)
end

--[[
    Keyboard handling, called by LÖVE2D each frame;
    passes in the key we pressed so we can access.
]]
function love.keypressed(key)

    if key == 'escape' then
        love.event.quit()
    -- if we press enter during either the start or serveSingleLeft phase, it should
    -- transition to the next appropriate state
    elseif key == 'enter' or key == 'return' then
        if gameState == 'serveSingleLeft' then
            gameState = 'playSingleLeft'
        elseif gameState =='serveSingleRightHard'then
        	gameState ='playSingleRightHard'

     	elseif gameState =='doneSingleRightHard'then
			-- game is simply in a restart phase here, but will set the serving
            -- player to the opponent of whomever won for fairness!
            gameState = 'serveSingleRightHard'

            ball:reset()

            -- reset scores to 0
            player1Score = 0
            player2Score = 0

            -- decide serving player as the opposite of who won
            if winningPlayer == 1 then
                servingPlayer = 2
            else
                servingPlayer = 1
            end

        elseif gameState =='serveSingleRightMid'then
        	gameState = 'playSingleRightMid'

        elseif gameState =='doneSingleRightMid' then
        	-- game is simply in a restart phase here, but will set the serving
            -- player to the opponent of whomever won for fairness!
            gameState = 'serveSingleRightMid'

            ball:reset()

            -- reset scores to 0
            player1Score = 0
            player2Score = 0

            -- decide serving player as the opposite of who won
            if winningPlayer == 1 then
                servingPlayer = 2
            else
                servingPlayer = 1
            end

        elseif gameState =='serveSingleLeftMid'then
        	gameState = 'playSingleLeftMid'
        elseif gameState =='serveSingleLeftHard'then
        	gameState ='playSingleLeftHard'

        elseif gameState =='doneSingleLeftHard' then
        	 -- game is simply in a restart phase here, but will set the serving
            -- player to the opponent of whomever won for fairness!
            gameState = 'serveSingleLeftHard'

            ball:reset()

            -- reset scores to 0
            player1Score = 0
            player2Score = 0

            -- decide serving player as the opposite of who won
            if winningPlayer == 1 then
                servingPlayer = 2
            else
                servingPlayer = 1
            end

        elseif gameState =='doneSingleLeftMid' then
        		 -- game is simply in a restart phase here, but will set the serving
            -- player to the opponent of whomever won for fairness!
            gameState = 'serveSingleLeftMid'

            ball:reset()

            -- reset scores to 0
            player1Score = 0
            player2Score = 0

            -- decide serving player as the opposite of who won
            if winningPlayer == 1 then
                servingPlayer = 2
            else
                servingPlayer = 1
            end



        elseif gameState =='serveSingleRight' then
        	gameState = 'playSingleRight'

        elseif gameState =='serveMulti' then
        	gameState = 'playMulti'

        elseif gameState =='doneMulti' then
        	 -- game is simply in a restart phase here, but will set the serving
            -- player to the opponent of whomever won for fairness!
            gameState = 'serveMulti'

            ball:reset()

            -- reset scores to 0
            player1Score = 0
            player2Score = 0

            -- decide serving player as the opposite of who won
            if winningPlayer == 1 then
                servingPlayer = 2
            else
                servingPlayer = 1
            end

        elseif gameState =='doneSingleRight' then
        	 -- game is simply in a restart phase here, but will set the serving
            -- player to the opponent of whomever won for fairness!
            gameState = 'serveSingleRight'

            ball:reset()

            -- reset scores to 0
            player1Score = 0
            player2Score = 0

            -- decide serving player as the opposite of who won
            if winningPlayer == 1 then
                servingPlayer = 2
            else
                servingPlayer = 1
            end


        elseif gameState == 'doneSingleLeft' then
            -- game is simply in a restart phase here, but will set the serving
            -- player to the opponent of whomever won for fairness!
            gameState = 'serveSingleLeft'

            ball:reset()

            -- reset scores to 0
            player1Score = 0
            player2Score = 0

            -- decide serving player as the opposite of who won
            if winningPlayer == 1 then
                servingPlayer = 2
            else
                servingPlayer = 1
            end
        end


    elseif key =='1' then
    	if gameState =='start'then
    		gameState = 'singlePlay'
    	elseif gameState  =='singlePlay' then
    		gameState = 'singlePlayLeftDiff'
    	elseif gameState =='singlePlayLeftDiff' then
    		gameState ='serveSingleLeft'--SELECTING EASY ON SINGLE PLAYER LEFT
    	elseif gameState =='singlePlayRightDiff' then
    		gameState ='serveSingleRight'--SELECTING EASY ON SINGLE PLAYER RIGHT
    	end
    elseif key =='2' then
    	if gameState =='start'then
    		gameState = 'serveMulti'
    	elseif gameState =='singlePlayRightDiff' then
    		gameState ='serveSingleRightMid'
    	elseif gameState =='singlePlay' then
    		gameState ='singlePlayRightDiff'
    	elseif gameState =='singlePlayLeftDiff'then
    		gameState ='serveSingleLeftMid' -- SELECTING MEDIUM ON SINGLE PLAYER LEFT
    	end
    elseif key =='3' then
    		if gameState=='singlePlayLeftDiff' then
    			gameState ='serveSingleLeftHard'--SELECTING HARD ON SINGLE PLAYER LEFT
    		elseif gameState=='singlePlayRightDiff'then
    			gameState ='serveSingleRightHard'--SELECTING HARD ON SINGLE PLAYER RIGHT
    		end
    end

end

--[[
    Called after update by LÖVE2D, used to draw anything to the screen,
    updated or otherwise.
]]
function love.draw()

    push:apply('start')

    -- clear the screen with a specific color; in this case, a color similar
    -- to some versions of the original Pong
    love.graphics.clear(40, 45, 52, 255)

    love.graphics.setFont(smallFont)

    if gameState == 'start' then
        love.graphics.setFont(smallFont)
        love.graphics.printf('Welcome to Pong!', 0, 100, VIRTUAL_WIDTH, 'center')
        love.graphics.printf('Press [1] for Single Player', 0, 110, VIRTUAL_WIDTH, 'center')
        love.graphics.printf('Press [2] for Multi Player', 0, 120, VIRTUAL_WIDTH, 'center')
        love.graphics.printf('Press [Esc] to Exit', 0, 130, VIRTUAL_WIDTH, 'center')
    elseif gameState =='singlePlay'then
    	love.graphics.setFont(smallFont)
        love.graphics.printf('Press [1] to play for Player 1 - Controls: W,S', 0, 110, VIRTUAL_WIDTH, 'center')
        love.graphics.printf('Press [2] to play for Player 2 - Controls: Up key, Down key', 0, 120, VIRTUAL_WIDTH, 'center')

    --DIFICULTY BOT

    elseif gameState =='singlePlayLeftDiff' then
    	love.graphics.setFont(smallFont)
        love.graphics.printf('Select Difficulty', 0, 110, VIRTUAL_WIDTH, 'center')
        love.graphics.printf('Press [1] for Easy Bot', 0, 120, VIRTUAL_WIDTH, 'center')
        love.graphics.printf('Press [2] for Medium Bot', 0, 130, VIRTUAL_WIDTH, 'center')
        love.graphics.printf('Press [3] for Hard Bot', 0, 140, VIRTUAL_WIDTH, 'center')
     elseif gameState =='singlePlayRightDiff' then
    	love.graphics.setFont(smallFont)
        love.graphics.printf('Select Difficulty', 0, 110, VIRTUAL_WIDTH, 'center')
        love.graphics.printf('Press [1] for Easy Bot', 0, 120, VIRTUAL_WIDTH, 'center')
        love.graphics.printf('Press [2] for Medium Bot', 0, 130, VIRTUAL_WIDTH, 'center')
        love.graphics.printf('Press [3] for Hard Bot', 0, 140, VIRTUAL_WIDTH, 'center')
     

     -- END OF DIFICULTYYY

    elseif gameState == 'serveSingleLeft' or gameState == 'serveSingleRight' or gameState =='serveMulti'
    	or gameState =='serveSingleLeftMid' or gameState =='serveSingleLeftHard'or gameState =='serveSingleRightMid'
    	or gameState =='serveSingleRightHard' then
        love.graphics.setFont(smallFont)
        love.graphics.printf('Player ' .. tostring(servingPlayer) .. "'s serve!",
            0, 10, VIRTUAL_WIDTH, 'center')


        love.graphics.printf('Press Enter to serve!', 0, 20, VIRTUAL_WIDTH, 'center')
    elseif gameState == 'doneSingleLeft' or gameState == 'doneSingleRight' or gameState == 'doneMulti' or
    	gameState=='doneSingleLeftMid' or gameState=='doneSingleLeftHard' or gameState =='doneSingleRightMid'
    	or gameState=='doneSingleRightHard'then
        -- UI messages
        love.graphics.setFont(largeFont)
        love.graphics.printf('Player ' .. tostring(winningPlayer) .. ' wins!',
            0, 10, VIRTUAL_WIDTH, 'center')
        love.graphics.setFont(smallFont)
        
    end

    if gameState=='serveSingleLeft' or gameState=='playSingleLeft' or gameState =='playSingleRight' or gameState == 'serveSingleRight' 
   	or gameState=='serveMulti' or gameState=='playMulti' or gameState=='playSingleLeftMid' or gameState=='serveSingleLeftMid'
   	or gameState=='serveSingleLeftHard' or gameState=='playSingleLeftHard' or gameState =='playSingleRightMid'or gameState =='serveSingleRightMid'
   	or gameState=='serveSingleRightHard'or gameState=='playSingleRightHard'then
    	displayScore()
		player1:render()
    	player2:render()
    	ball:render()
    	displayFPS()
	end
    push:apply('end')
   
end

--[[
    Renders the current FPS.
]]
function displayFPS()
    -- simple FPS display across all states
    love.graphics.setFont(smallFont)
    love.graphics.setColor(0, 255, 0, 255)
    love.graphics.print('FPS: ' .. tostring(love.timer.getFPS()), 10, 10)
end

--[[
    Simply draws the score to the screen.
]]
function displayScore()
    -- draw score on the left and right center of the screen
    -- need to switch font to draw before actually printing
    love.graphics.setFont(scoreFont)
    love.graphics.print(tostring(player1Score), VIRTUAL_WIDTH / 2 - 50,
        VIRTUAL_HEIGHT / 3)
    love.graphics.print(tostring(player2Score), VIRTUAL_WIDTH / 2 + 30,
        VIRTUAL_HEIGHT / 3)
end
